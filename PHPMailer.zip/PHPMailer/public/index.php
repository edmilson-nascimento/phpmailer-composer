<?php

require "../vendor/autoload.php";

use app\src\Mail;

$mail = new Mail;
$mail->send();