<?php

namespace app\src;

use PHPMailer\PHPMailer\PHPMailer;

class Mail {

	public function send() {

		$mail = new PHPMailer(false); // Passing `true` enables exceptions

		try {

			$mail->SMTPDebug = 0; // Debugar: 1 = erros e mensagens, 2 = mensagens apenas
			$mail->isSMTP(); // Set mailer to use SMTP

			// $mail->Host = 'smtp.gmail.com'; // Specify main and backup SMTP servers
			// $mail->SMTPAuth = true; // Enable SMTP authentication
			// $mail->Username = 'eddyenj'; // SMTP username
			// $mail->Password = '22aa8080'; // SMTP password
			// $mail->SMTPSecure = 'SSL'; // Enable TLS encryption, `ssl` also accepted
			// $mail->Port = 465; // TCP port to connect to

			$mail->Host = 'smtp-mail.outlook.com'; // Specify main and backup SMTP servers
			$mail->SMTPAuth = true; // Enable SMTP authentication
			$mail->Username = 'e.nascimento@gmail.com'; // SMTP username
			$mail->Password = '22aa8080'; // SMTP password
			$mail->SMTPSecure = 'TLS'; // Enable TLS encryption, `ssl` also accepted
			$mail->Port = 587; // TCP port to connect to

			//Recipients
			// $mail->setFrom('vinicius.cantuario@gmail.com', 'Edmilson Nascimento');
			$mail->setFrom('site@abapconsulting.com.br', 'Edmilson Nascimento');
			$mail->addAddress('site@abapconsulting.com.br', 'Site');
			// $mail->addAddress('ellen@example.com'); // Name is optional
			// $mail->addReplyTo('info@example.com', 'Information');
			// $mail->addCC('cc@example.com');
			// $mail->addBCC('bcc@example.com');

			//Attachments
			// $mail->addAttachment('/var/tmp/file.tar.gz'); // Add attachments
			// $mail->addAttachment('/tmp/image.jpg', 'new.jpg'); // Optional name

			//Content
			$mail->isHTML(true); // Set email format to HTML
			$mail->Subject = 'Contato do site';
			$mail->Body = 'Aqui vai ficar o <b>corpo do e-mail!</b>';
			// $mail->AltBody = 'This is the body in plain text for non-HTML mail clients';

			$mail->send();
			echo 'Mensagem enviada.';
		} catch (Exception $e) {
			// echo 'Message could not be sent. Mailer Error: ', $mail->ErrorInfo;
			echo 'E-mail não enviado.', $mail->ErrorInfo;
		}
	}
}